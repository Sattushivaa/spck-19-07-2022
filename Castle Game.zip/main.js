import { Aliena } from '/components/Aliena/aliena.js'
import Hero from '/components/Hero/hero.js'
import { Loader } from '/components/Loader/loader.js'
;
Hero.appender = _('#playscreen')[0];
let playBtn = _('#play_btn')[0];

playBtn.addEventListener('click',()=>{
  _('#levels')[0].style.left = '0vw';
})
_('#levels .backToHome')[0].addEventListener('click',()=>{
  _('#levels')[0].style.left = '-100vw';
})

window.shootOne = function(x,y){
  let ball = Hero.init();
  setTimeout(()=>{
    Hero.shoot(x,y,ball);
  },100);
}

