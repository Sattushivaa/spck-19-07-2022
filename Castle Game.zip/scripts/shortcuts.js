const _ = (e) => document.querySelectorAll(e);
const __ = (el) => document.createElement(el);
HTMLElement.prototype._ = function(e){return this.querySelectorAll(e)};
HTMLElement.prototype.setStyle = function(obj){return Object.assign(this.style,obj)};
