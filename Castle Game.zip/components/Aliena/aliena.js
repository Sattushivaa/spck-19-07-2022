const overlayStyles = {
  position : 'fixed',
  width : '100vw',
  height : '100vh',
  top : '0px',
  left : '0px',
  background : '#00000080',
  textAlign : 'center'
}
const alienaStyles = {
  float : 'left',
}
const messageStyles = {
  background : '#00000090',
  borderRadius : '10px',
  border : '2px solid white',
  color : 'white',
  padding : '10px',
  margin : '10px',
  display : 'inline-block',
  width : '300px',
  maxHeight : '300px',
  overflowX : 'auto',
  boxShadow : '0px 0px 10px white',
  textAlign : 'center'
}
const btnStyles = {
  background : 'white',
  color : 'black',
  display : 'block',
  margin : 'auto',
  marginTop : '10px'
}


export class Aliena {
  overlay = __('div');
  textCont = __('span');
  callbacks = {};
  callback = null;
  defaultAction = function(){
    this.overlay.remove();
    this.callback?this.callback():null;
  };
  ANIMATE(str,textCont,timestamp){
    let count = 0;
    textCont.innerHTML = '';
    const animate = ()=>{
      if(count<str.length){
        let span = __('span');
        span.innerText = str[count];
        textCont.append(span);
        count ++;
        setTimeout(animate,timestamp);
      }
    }
    animate();
  }
  say(message){
    let timestamp = 50;
    let overlay = this.overlay;
    overlay.setStyle(overlayStyles);
    document.body.append(overlay);
    let img = __('img');
    img.src = '/components/Aliena/aliena.png';
    img.width = 300;
    img.style.background = 'radial-gradient(white,transparent, transparent)';
    overlay.append(img);
    let msg = __('div');
    msg.align = 'right';
    msg.setStyle(messageStyles);
    overlay.append(msg);
    let msgText = this.textCont;
    //msgText.innerText = message;
    msg.append(msgText);
    let fab = __('button');
    fab.innerText = 'OKAY';
    fab.setStyle(btnStyles);
    msg.append(fab);
    // TODO:ANIMATION TEXT
    /*str.forEach(letter=>{
      let span = __('span');
      span.innerText = letter;
      msgCont.append(span);
    })*/
    fab.onclick = () => {
      let ev = new Event('dismount');
      overlay.dispatchEvent(ev);
      this.defaultAction?.();
    };
    this.ANIMATE(message,msgText,10);
    return overlay;
  }
  CONTINUE(...messages){
    let limit = messages.length;
    let count = 0;
    this.defaultAction = function(){
      this.callbacks[count]?.();
      count++;
      if(count<limit){
        this.ANIMATE(messages[count],this.textCont,10);
      } else {this.overlay.remove()};
    }
    this.say(messages[0]);
  }
  PAGECALLBACK(number,func){
    this.callbacks[number]=func;
    number==0?this.callback=func:null;
  }
}