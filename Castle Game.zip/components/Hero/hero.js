const ballStyles = {
  width : '20px',
  height : '20px',
  borderRadius : '10px',
  transition : 'all 1000ms',
  position : 'fixed',
  top : screen.availHeight/2 + 'px',
  left : screen.availWidth/2 + 'px',
  background : 'black',
}
export default class Hero {
  //origin_x = screen.availWidth/2;
  //origin_y = screen.availHeight/2;
  appender = null;
  static init(){
    let ball = __('span');
    this.appender.append(ball);
    ball.setStyle(ballStyles);
    return ball;
  }
  static shoot(x,y,ball){
    ball.style.top = y + 'px';
    ball.style.left = x + 'px';
  }
}
