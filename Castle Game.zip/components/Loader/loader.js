const loaderStyles = {
  
}
export class Loader {
  static load(obj={}){
    let loaders = _('.loader');
    let time = parseFloat(getComputedStyle(loaders[0]).transitionDuration)*1000;
    loaders.forEach((img)=>{
      img.style.width = '100vw';
    });
    setTimeout(()=>obj.onhide?.(),time);
    setTimeout(()=>{
      loaders.forEach((img)=>{
        img.style.width = '0vw';
      })
    },1000);
  }
  static wait(){
    // wait for something
  }
}
