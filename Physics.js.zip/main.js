console.log('Physics.js v0.1');
const kg = 1;
const $=(e)=>document.querySelectorAll(e);
const rad=(d)=>d*Math.PI/180;
const deg=(r)=>r/Math.PI/180;
const str = $('.str');
const styles1 = getComputedStyle(str[0]);
const x1= parseInt(styles1.left);
const y1 = parseInt(styles1.top);
const styles2 = getComputedStyle(str[1]);
const x2 = parseInt(styles2.left);
const y2 = parseInt(styles2.top);
const stone = $('#stone')[0];
stone.mass = 1*kg;
let theta = 0;

let engine = PhysicsEngine;
engine._surface_ = $('#surface')[0];


const initSling = () => {
  engine.projectile(stone,(parseInt(str[1].style.height)*4),theta);
  Object.assign(str[0].style,{
    height : '50px',
    transform : 'rotateZ(-90deg)'
  })
  Object.assign(str[1].style,{
    height : '50px',
    transform : 'rotateZ(90deg)'
  })
  //alert(theta);
}


const sling = (e)=>{
  let clientX = e.touches[0].clientX;
  let clientY = e.touches[0].clientY;
  let dy1 = clientY-y1,
      dy2 = clientY-y2,
      dx1 = x1-clientX,
      dx2 = x2-clientX;
  let angle1 = Math.atan2(dx1,dy1);
  angle1 = deg(angle1);
  let angle2 = Math.atan2(dx2,dy2);
  angle2= deg(angle2);
  let h1 = Math.sqrt(dx1*dx1+dy1*dy1);
  let h2 = Math.sqrt(dx2*dx2+dy2*dy2);
  str[0].style.transform = 'rotateZ('+angle1+'deg)';
  str[0].style.height = h1 + 'px';
  str[1].style.height = h2 + 'px';
  str[1].style.transform = 'rotateZ('+angle2+'deg)';
  stone.style.left = clientX + 'px';
  stone.style.top = clientY + 'px';
  
  theta = parseInt((angle1+angle2)/2);
  
  $('#th')[0].innerText = theta;
  $('#x')[0].innerText = Math.cos(theta*Math.PI/180);
  $('#y')[0].innerText = Math.sin(theta*Math.PI/180);
}


str[0].addEventListener('touchmove',sling);
str[1].addEventListener('touchmove',sling);
str[0].addEventListener('touchend',initSling);
str[1].addEventListener('touchend',initSling);

// let observer = new MutationObserver((mutations)=>console.log(mutations[0]));
// observer.observe(stone,{attributes:true});
