const m = 20;
const g = 9.8*m;
let PhysicsEngine = {
  _surface_ : null,
  _projectile_ : {
    s : (u,t,a)=>(u*t)+(1/2)*a*t*t,
    v : (u,t,a)=>u+a*t,
    vv : (u,a,h)=>u*u+2*a*h,
    t : (u,a)=>u/Math.abs(a),
    h_t: (h,a)=>Math.sqrt(2*h/a),
  },
  projectile : (el,u,theta)=>{
    //console.log(theta);
    var u_x = Math.cos(theta*60);
    var u_y = Math.sin(theta*60);
    u_x = Math.abs(u_x)*u;
    u_y = Math.abs(u_y)*u;
    //console.log(u_x,u_y);
    const t = PhysicsEngine._projectile_.t(u_y,-g);
    t>0?console.log(t):alert(t);
    const t_ms = t*1000;
    const stl = getComputedStyle(el);
    const x1 = parseInt(stl.left);
    const y1 = parseInt(stl.top);
    const H = PhysicsEngine._projectile_.s(u_y,t,-g);
    let t__up = 0;
    let t__total = 0;
    let t__dn = 0;
    let direction = 'up';
    let tmp = 3;
    
    function move(){
      
      if(parseFloat(getComputedStyle(el).top)>=parseFloat(getComputedStyle(PhysicsEngine._surface_).top)){
          alert('stop');
          return;
        }
      
      let x2s = PhysicsEngine._projectile_.s(u_x,t__total/1000,0);
      el.style.left = x1+x2s+'px';
      t__total+=tmp;
      
      if(direction=='up'){
        if(parseFloat(getComputedStyle(el).top<=y1-H)){direction='down'}
        let t__ = t__up/1000;
        let s = PhysicsEngine._projectile_.s(u_y,t__,-g);
        t__up+=tmp;
        el.style.top = y1-s+'px';
      } else {
        let t__ = t__dn/1000;
        let s = PhysicsEngine._projectile_.s(0,t__,g);
        t__dn+=tmp;
        el.style.top = y1+s+'px';
        
      }
      
      setTimeout(move,tmp);
    }
    setTimeout(move,0);
  }
};
